<?php
if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section id="content">
	<div id="buddypress">
	    <div class="<?php echo vibe_get_container(); ?>">

<?php 	    	
		do_action( 'bp_before_course_home_content' );